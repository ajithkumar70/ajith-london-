package com.tekclover.wms.core.model.idmaster;

import lombok.Data;

@Data
public class OrderTypeId {

    private String orderTypeId;


}
