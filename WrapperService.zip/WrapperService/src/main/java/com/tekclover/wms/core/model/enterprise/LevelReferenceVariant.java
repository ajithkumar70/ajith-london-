package com.tekclover.wms.core.model.enterprise;

import lombok.Data;

@Data
public class LevelReferenceVariant {
    private String levelReference;

}
