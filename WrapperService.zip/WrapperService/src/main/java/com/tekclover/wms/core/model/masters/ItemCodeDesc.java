package com.tekclover.wms.core.model.masters;

import lombok.Data;

@Data
public class ItemCodeDesc {

	private String itemCode;
	private String manufacturerName;
	private String description;
}
