package com.tekclover.wms.core.model.masters;

import lombok.Data;

@Data
public class LikeSearchInput {

	String likeSearchByDesc;
	String companyCodeId;
	String plantId;
	String languageId;
	String warehouseId;
}
