package com.tekclover.wms.core.model.enterprise;

import lombok.Data;

@Data
public class LevelReference {
    private String levelReference;
}
